#ifndef LAB12_H
#define LAB12_H

class Lab12 {
    //Data Members
    private:
    int value = 0;
    public:
    //Functions but methods aren't defined only prototypes
        void setValue(int value);
    int getValue();
};
#endif
