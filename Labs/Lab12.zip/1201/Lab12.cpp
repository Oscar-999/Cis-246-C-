#include "Lab12.h"

void Lab12::setValue(int val) {
  value = val;
};

int Lab12::getValue() {
  return value;
}
